#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>



using namespace std;


class Scheme: public vector<string> 
{
    
    private:
        
     
        
    public:
        Scheme(){}
        
};


