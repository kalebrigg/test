#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "DatalogProgram.h"
#include "Database.h"
#include "Predicate.h"
#include "Parameter.h"


using namespace std;


class Interpreter
{
    private:
       DatalogProgram mydata;
       
       Database datab;  
                
     
        
    public:
        Interpreter( DatalogProgram in );
        
        
        void make_relation();
        void fill_relation(); 
        
        void test_func1(); 
        void test_func2(); 
        
        void evaluate_queries(); 
        
        void evaluate_all_rules(); 
        bool evaluate_rule( Rule r ); 
        
        Relation evaluate_predicate( Predicate p, bool is_q );
        
        
};



