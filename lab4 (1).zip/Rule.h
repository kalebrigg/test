#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "Predicate.h"

using namespace std;


class Rule
{
    private:
        Predicate headpredicate; 
        vector<Predicate> rule_predicates; 
        
    public:
        void setHeadPred ( Predicate pred);
        void addpredicate(Predicate pred);
        void clear_rule_predicates(); 
        void clear_headpred_param(); 
        
        void rule_toString(); 
        
        vector<Predicate> get_rule_predicates_vector();
        Predicate get_headpredicate(); 
       
};


