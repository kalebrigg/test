#include "Relation.h"

using namespace std;

Relation:: Relation( string name, Scheme s)
{
    relation_name = name; 
    column_headers = s; 
    
}

void Relation:: add_tuple ( Tuple t)
{
    rows.insert( t ); 
    
}

Relation:: Relation ( string name, Scheme s , set<Tuple> new_set )
{
    relation_name = name; 
    column_headers = s;
    rows = new_set; 
    
}

Relation Relation:: select1 ( string s , int col_index )
{
    // cout << "START select function 1:" << endl; 
    // cout << "Looking for " << s << " in the " << col_index << " column." << endl; 
    set<Tuple> newset; 
    
    for( Tuple tuple : rows )
    {
        
        // cout << "Tuple: " << tuple.at(col_index ) << "compared to: " << s << endl; 
        
        if ( tuple.at( col_index )  == s )
		{
		  //  cout << "finds: " << tuple.at( col_index ) << endl; 
		    newset.insert( tuple );
		}	
		    

    }
    
    return Relation( relation_name , column_headers , newset ); 
    
}


Relation Relation:: select2 ( int col_index1, int col_index2 )
{
    set<Tuple> newset; 
    
    for ( auto tuple : rows )
    {
        
        if ( tuple.at( col_index1 ) == tuple.at( col_index2) )
		{
		    newset.insert(tuple);
		}
		
        
    }
    // return Relation(); 
    return Relation( relation_name , column_headers , newset  );
    
}

Relation Relation:: project ( vector<int> column_ints )
{
    Scheme new_scheme; 
     
    set<Tuple> new_rows; 
    
    for ( int i : column_ints )
    {
        string s = column_headers.at(i);
        new_scheme.push_back( s );
        
    }
    
    
    for ( auto tuple : rows )
    {
        Tuple tup;
        
        for ( int i : column_ints )
        {
            
            string t = tuple.at( i );
            tup.push_back( t ); 
        }
        
        new_rows.insert( tup );     
    }
    
    
    
    
    return Relation( relation_name, new_scheme, new_rows ); 
}
        
Relation Relation:: re_name ( Scheme s )
{

    return Relation( relation_name, s , rows); 
}




void Relation:: print_scheme_vec()
{
    int i = 0;
    cout << "Relation name: " << relation_name << endl; 
    for ( auto s : column_headers )
    {
        cout << "Column header (" << i <<  "): " <<  s << endl; 
        
        i++;
    }
}

void Relation:: print_rows()
{
    
    cout << "Relation name: " << relation_name << endl;
    
    for ( auto s : rows )
    {
        int i = 0;
        
        for ( auto a : s )
        {
            cout << "Tuple (" << i << "): " << s.at(i) << endl; 
        
            i++;
        }
        
    }
    
    
}

void Relation:: query_tostring( Predicate p)
{
    
    //cout << relation_name << "("; 
    
    cout << p.toString() << "? ";
    
    
    if (rows.size() > 0 )
    {
        cout << "Yes(" << rows.size() << ")" << endl;
        
        if (column_headers.size() == 0)
            return; 
        
    }
    else
    {
        cout << "No" << endl; 
    }
    
    
    int n = column_headers.size(); 
    
    for ( auto r : rows )
    {
        
        for ( int i = 0; i < n ; i++ )
        {
            if (i == 0)
            {
                cout << "  "; 
            }
            else
            {
                cout << ", ";
            }
            
            cout << column_headers[i] << "=" << r.at(i); 
        }
        cout << "\n"; 
    }
    
}

Relation Relation:: join ( Relation R2)
{
    // R3 = R1.join( R2)
    // cout << "JOINING NOW" << endl; 
    
    Scheme column_headers2 = R2.return_schemes();
    Scheme combined_scheme = combine_schemes( column_headers , column_headers2 ); 

    set<Tuple> new_rows;
    
    // cout << "SCHEMES COMBINED" << endl; 
    
	for( Tuple tup1 : rows )               //tuples in R1 
	{
		for( Tuple tup2 : R2.return_tuples() )                             //Tuples in R2 )
		{
		    
			if ( joinable( tup1, tup2, column_headers , column_headers2 ) )
			{
			     // cout << "ENTERING JOINABLE" << endl; 
			      Tuple combined_tuples = combine_tuples( tup1, tup2, column_headers, column_headers2 ); 
			      new_rows.insert( combined_tuples ); 
			
			}
		}
	}
    
    return Relation ( relation_name , combined_scheme , new_rows ); 
    
}

bool Relation:: joinable ( Tuple t1, Tuple t2, Scheme s1, Scheme s2 )
{

	for ( unsigned int i = 0; i < s1.size(); i++  )        // Scheme 1
	{
	    for ( unsigned int j = 0; j < s2.size(); j++ )     // Scheme 2 
	    {
	        if( s1[i] == s2[j]  )
	        {
	            if( t1.at(i) !=  t2.at(j) ) 
	            {
	                 return false;
	            }
	        }
	    }
	}
		
	return true; 
}

Scheme Relation:: combine_schemes( Scheme S1, Scheme S2  )
{
    Scheme new_scheme; 
    
    
    for (  unsigned int i = 0; i < S1.size(); i++ )
    {
        new_scheme.push_back( S1.at(i) );
    }
    
    for ( unsigned int i = 0; i < S2.size(); i++ )
    {
        bool found = false; 
        
        for (unsigned int j = 0; j < new_scheme.size(); j++ )
        {
            if ( new_scheme.at(j) == S2.at(i) )
            {
                found = true;  
            }
        }
        
        if ( found == false )
        {
            new_scheme.push_back( S2.at(i) ); 
        }
        
    }
    
    
    return new_scheme; 
}

Tuple Relation:: combine_tuples( Tuple t1, Tuple t2, Scheme s1, Scheme s2 )
{
    // cout << "STARTING TUPLE JOIN" << endl; 
    Tuple new_tups;

    for ( unsigned int i = 0; i < s1.size(); i++)
    {
        new_tups.push_back( t1.at(i) ); 
    }
    
    // cout << "ORIGINAL COPIED" << endl; 
    
    for ( unsigned int i = 0; i < s2.size(); i++ ) //t2
    {
        bool found = false;
        
        for ( unsigned int j = 0; j < s1.size(); j++ ) // new
        {
            if ( s2.at(i) == s1.at(j) )
            {
                found = true;  
            }
        }
        
        if ( found == false )
        {
            new_tups.push_back( t2.at(i) ); 
        }
        
    }
    // cout << "RETURNING NEW TUPLES" << endl; 
    return new_tups; 
}

bool Relation:: union_function( Relation existing_relation )
{
    bool relation_changed = false; 
    
    set<Tuple> new_tups;
    // cout << "STARTING UNION" << endl; 
    
    
    for ( auto t : existing_relation.return_tuples() )
    {
       
        
        if( rows.count( t ) == 0  )
        {
            
            rows.insert( t );
            new_tups.insert( t );
            relation_changed = true; 
        }
        
       
    }

    string temp;
    /*
    for ( auto s : new_tups )
    {
        unsigned int i = 0;
        bool first = true; 
    
        
        for ( auto a : s )
        {
            if (first)
            {
                cout << "  ";
                first = false; 
            }
                
            
            cout << column_headers.at(i) << "=" << s.at(i) << " "; 
             
            
            if ( a.size() > ( i + 2 ) )
                cout << ", "; 
            
        
            i++;
        }
        cout << endl; 
        
    }*/
    
    for ( auto s : new_tups )
    {
        unsigned int i = 0;
        bool first = true; 
        temp = ""; 
        
        for ( auto a : s )
        {
            if (first)
            {
                cout << "  ";
                first = false; 
            }
                
            
            temp += column_headers.at(i) + "=" + s.at(i) + ", "; 
             
        
        
            i++;
        }
        temp.pop_back();
        temp.pop_back(); 
        cout << temp; 
        cout << endl; 
        
    }
    // cout << "----------------------------------------------" << endl; 
   
    //return Relation( relation_name , column_headers,  rows ); 
    // cout << "FINISH UNION" << endl; 
    return relation_changed; 
}





Scheme Relation:: return_schemes()
{
    return column_headers; 
}

string Relation:: return_relation_name()
{
    return relation_name; 
}

set<Tuple> Relation:: return_tuples()
{
    return rows; 
}