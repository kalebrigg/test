#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "Parameter.h"

using namespace std;


class Predicate
{
    private:
        vector<Parameter*> parameters;
        string headID; 
        
        
    public:
        //Predicate(); 
        //~Predicate(); 
    
        void addParam(Parameter* parameter_value); 
       
        void setHeadID(string head_ID);
        void clear_vector_param(); 
       
        string get_headID();
        
        vector<Parameter*> get_param_vector(); 
        string toString();
};


