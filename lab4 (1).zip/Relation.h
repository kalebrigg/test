#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <set> 
#include <map>
#include "Scheme.h"
#include "Tuple.h"
#include "Predicate.h"


using namespace std;


class Relation
{
    private:
        string relation_name;
        Scheme column_headers;  // vector 
        set<Tuple> rows;        // set of Tuple, Tuple is vec of string
     
        
    public:
        Relation(){}
        Relation( string name, Scheme s );
        Relation( string name, Scheme s , set<Tuple> new_set );
        
        void add_tuple ( Tuple t );
        
        
        Relation select1 ( string s , int col_index );
        Relation select2 ( int col_index1, int col_index2 );                        //Creating Relations
        Relation project ( vector<int> column_ints );
        Relation re_name ( Scheme s );
        
        Scheme combine_schemes( Scheme S1, Scheme S2 );
        Tuple combine_tuples( Tuple t1, Tuple t2, Scheme s1, Scheme s2  ); 
        bool joinable (Tuple t1, Tuple t2, Scheme s1, Scheme s2);                   // Join functions
        Relation join (Relation R2 ); 
        
        
        bool union_function( Relation existing_relation );

        
        Scheme return_schemes();
        string return_relation_name();
        set<Tuple> return_tuples(); 
        
        void print_scheme_vec(); 
        void print_rows(); 
        void query_tostring( Predicate p ); 
};


