#include "Expression.h"

using namespace std; 

Expression:: Expression()
{
    
}

Expression:: ~Expression()
{
    //clear(); 
    //  delete left; 
    //  delete right;
    
}

Expression::  Expression( Parameter* leftt, string opp , Parameter* rightt)
{
    left = leftt; 
    op = opp;
    right = rightt; 
}

void Expression :: set_operator( string string_operator)
{
    op = string_operator; 
}

string Expression :: get_operator()
{
    return op;
}

string Expression:: param_toString()
{
    string temp; 
    
    temp += "(" + left->param_toString();
    temp += op; 
    temp += right->param_toString() + ")";
    
    return temp;
    
}

void Expression:: clear()
{
  //  left->clear(); 
  //  right->clear();
    //delete left;
    //delete right; 
    
}