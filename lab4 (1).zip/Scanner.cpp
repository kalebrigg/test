#include "Scanner.h"

using namespace std; 

Scanner:: Scanner()
{
    number_of_tokens = 0; 
}

vector<Token> Scanner:: create_token( string file_name)
{
   InputReader i; 
   i.read_file( file_name); 
    
    //create a private vector 
    
     
    
    while (!i.eof_check())// while not eof 
    {
        
        char c = i.get_character(); 
        
//        cout << "C test: "<<  c << endl; 
        
         switch( c )
         {
            
            
            case ',': 
            {
                Token( COMMA, ",",  i.get_line_number() ); 
                tokens_created.push_back(Token( COMMA, ",", i.get_line_number() )); 
             //   cout << "(" << "COMMA,\",\"," << i.get_line_number() << ")\n"; 
                number_of_tokens++;
                    break; 
            }
            
            case '.': 
            {
                Token( PERIOD, ".", i.get_line_number() ); 
                tokens_created.push_back( Token ( PERIOD, ".", i.get_line_number() )); 
            //    cout << "(" << "PERIOD,\".\"," << i.get_line_number() << ")\n"; 
                number_of_tokens++;
                    break; 
            }
                
            case '?': 
            {
                Token( Q_MARK, "?", i.get_line_number() ); 
                tokens_created.push_back( Token ( Q_MARK, "?", i.get_line_number() )); 
            //    cout << "(" << "Q_MARK,\"?\"," << i.get_line_number() << ")\n"; 
                number_of_tokens++;
                    break; 
            }
            
            case '(': 
            {
                Token( LEFT_PAREN, "(", i.get_line_number() ); 
                tokens_created.push_back( Token ( LEFT_PAREN, "(", i.get_line_number() )); 
            //    cout << "(" << "LEFT_PAREN,\"(\"," << i.get_line_number() << ")\n"; 
                number_of_tokens++;
                    break; 
            }
            
            case ')': 
            {
                Token( RIGHT_PAREN, ")", i.get_line_number() ); 
                tokens_created.push_back( Token ( RIGHT_PAREN, ")", i.get_line_number() )); 
            //    cout << "(" << "RIGHT_PAREN,\")\"," << i.get_line_number() << ")\n"; 
                number_of_tokens++;
                    break; 
            }
            
            
            case ':': //// need to ask about colon dash  :- 
            {
                if (  i.peek_char() == '-')
                {
                    Token( COLON_DASH, ":-", i.get_line_number() ); 
                    tokens_created.push_back( Token ( COLON_DASH, ":-", i.get_line_number() )); 
            //        cout << "(" << "COLON_DASH,\":-\"," << i.get_line_number() << ")\n"; 
                    number_of_tokens++;
                    
                    i.get_character(); 
                    
                  //  cout << "Throwing away: " << throw_away << endl; 
                        break; 
                }
                
                Token( COLON, ":", i.get_line_number() ); 
                tokens_created.push_back( Token ( COLON, ":", i.get_line_number() )); 
            //    cout << "(" << "COLON,\":\"," << i.get_line_number() << ")\n"; 
                number_of_tokens++;
                    break; 
            }
            
            case '*': 
            {
                Token( MULTIPLY, "*", i.get_line_number() ); 
                tokens_created.push_back( Token ( MULTIPLY, "*", i.get_line_number() )); 
            //    cout << "(" << "MULTIPLY,\"*\"," << i.get_line_number() << ")\n"; 
                number_of_tokens++;
                    break; 
            }
            
            case '+':
            {
                Token( ADD, "+", i.get_line_number() ); 
                tokens_created.push_back( Token ( ADD, "+", i.get_line_number() )); 
            //    cout << "(" << "ADD,\"+\"," << i.get_line_number() << ")\n"; 
                number_of_tokens++;
                    break;
            }
            
            case '\'':    // STRING TOKEN 
            {
        //        cout << "           RECOGNIZES STRING TOKEN" << endl; 
                string_function( i );
                    break; 
            }
            
            case '#':    // COMMENT TOKEN 
            {
       //         cout << "           RECOGNIZES COMMENT TOKEN" << endl; 
                comment_function( i ); 
                break; 
            }
            
            case EOF: 
            {
            //    cout << "EOF HIT" << endl; 
                Token( ENDOFFILE, "", i.get_line_number() ); 
                tokens_created.push_back( Token ( ENDOFFILE, "", i.get_line_number() )); 
            //    cout << "(" << "EOF,\"\"," << i.get_line_number()  << ")\n"; 
                 number_of_tokens++;
    
            //     cout << "Total Tokens = " << number_of_tokens << endl; 
                break; 
    
            }
            
            default: 
        //        cout << "           RECOGNIZES POSSIBLE ID TOKEN" << endl; 
                
                if ( isalpha(c) )
                {
                    determine_if_ID_token( i, c); 
                }
                else
                {
                    string temp;
                    temp = c; 
                    
                //     cout << "MAYBE HAPPENING HERE" << endl; 
                     
                    Token( UNDEFINED, temp , i.get_line_number() ); 
                    tokens_created.push_back( Token ( UNDEFINED, temp , i.get_line_number() )); 
             //       cout << "(" << "UNDEFINED,\"" << temp << "\"," << i.get_line_number() << ")\n";                     
                    number_of_tokens++;
                    break;
                }
        }
    

    }
    

   return tokens_created;  
    
}

void Scanner::string_function( InputReader &i)
{
 //   cout << "           START STRING FUNCTION" << endl; 
  //  InputReader i; 
    int num_line_started_on = 0;
    
    num_line_started_on = i.get_line_number(); 
    string s_value = "\'"; 
    
    char temp;
    
    while (!i.eof_check())
    {
 //       cout << "loop" << endl; 
      //  string temp = "\"";
        
    
        temp = i.get_character_with_space();
//        cout << "TEMP holds: " << temp << endl; 
        
        if ( temp == '\'' )   //block comment
        {
           char a = i.peek_char();
//           cout << "CHAR A IS: " << a << endl; 
           if ( a == '\'' )
           {
                s_value += i.get_character_with_space(); 
           }
           else
           {
                s_value += "\'";
                Token( STRING, s_value, num_line_started_on ); 
                tokens_created.push_back( Token ( STRING, s_value, num_line_started_on )); 
            //    cout << "(" << "STRING,\"" << s_value << "\"," << num_line_started_on << ")\n"; 
                number_of_tokens++;
                    return; 
                
           }
        }
     
        s_value += temp; 
//        cout << "String Value: " << s_value << endl; 
    }
    
   // s_value += "\'";
   
   s_value.pop_back(); 
   
    Token( UNDEFINED, s_value, num_line_started_on ); 
    tokens_created.push_back( Token ( UNDEFINED, s_value, num_line_started_on )); 
//    cout << "(" << "UNDEFINED,\"" << s_value << "\"," << num_line_started_on << ")\n"; 
    number_of_tokens++;
    
    Token( ENDOFFILE, "", i.get_line_number()  ); 
    tokens_created.push_back( Token ( ENDOFFILE, "", i.get_line_number() )); 
//    cout << "(" << "EOF,\"\"," << i.get_line_number()  << ")\n"; 
     number_of_tokens++;

//    cout << "Total Tokens = " << number_of_tokens << endl; 
    return; 


}

void Scanner:: comment_function( InputReader &i)
{
 //   cout << "           START COMMENT FUNCTION" << endl; 

    int num_line_started_on = 0;
    num_line_started_on = i.get_line_number();
    bool possible_end = false; 
    
   // char temp; 
    string comment_value = "#";
    
    if ( i.peek_char() == '|') // block comment
    {
        comment_value += i.get_character_with_space();
       
        while ( !i.eof_check() )
        {
            if(possible_end)
            {
                if (i.peek_char() == '#' )  //block comment has ended
                {
                    comment_value += i.get_character_with_space(); 
                    
                    Token( COMMENT, comment_value, num_line_started_on ); 
                    tokens_created.push_back( Token ( COMMENT, comment_value, num_line_started_on )); 
                 //   cout << "(" << "COMMENT,\"" << comment_value << "\"," << num_line_started_on << ")\n"; 
                    number_of_tokens++;
                        return; 
                }
                else
                {
                    possible_end = false; 
                }
            }
            
            if (i.peek_char() == '|')
            {
                possible_end = true; 
            }
            
            comment_value += i.get_character_with_space(); 
            
       //     cout << "COMENT VALUE: " << comment_value << endl; 
            
        }
        
        //  UNDEFINED TOKEN, FILES ENDS BEFORE COMMENT CLOSE
       
        Token( UNDEFINED, comment_value, num_line_started_on ); 
        tokens_created.push_back( Token ( UNDEFINED, comment_value, num_line_started_on )); 
    //    cout << "(" << "UNDEFINED,\"" << comment_value << "\"," << num_line_started_on << ")\n"; 
            number_of_tokens++;
        
        Token( ENDOFFILE, "", i.get_line_number() ); 
        tokens_created.push_back( Token ( ENDOFFILE, "", i.get_line_number() )); 
    //    cout << "(" << "EOF,\"\"," << i.get_line_number() << ")\n"; 
         number_of_tokens++;
    
   //     cout << "Total Tokens = " << number_of_tokens << endl; 
     
        return; 
      
     
      
    }
    
    
    else             // regular comment
    {
  //      cout << "Start Reg. Comment" << endl; 
        
        while ( (!i.eof_check())  && (i.peek_char() != '\n') )
        {
            char a = i.get_character_with_space(); 
   //         cout << "Char A is: " << a << endl; 
            comment_value += a; 
          
        }
        
  //      cout << "OUTSIDE WHILE" << endl; 
            Token( COMMENT, comment_value, num_line_started_on ); 
            tokens_created.push_back( Token ( COMMENT, comment_value, num_line_started_on )); 
       //     cout << "(" << "COMMENT,\"" << comment_value << "\"," << num_line_started_on << ")\n"; 
            number_of_tokens++;
            return; 
                 
    }
          
    
}

void Scanner:: determine_if_ID_token( InputReader &i, char c)
{
    string word_value;
    word_value = c; 
 //   cout << "Starting Word Value: " << word_value << endl; 
    while ( isalnum(i.peek_char()) )
    {
 //       cout << "C value is: " << endl; 
        
        word_value += i.get_character();
        //c = i.peek_char(); 
         
 //       cout << "Word Value: " << word_value << endl; 
    }
    
    if ( word_value == "Schemes")
    {
        Token( SCHEMES, word_value, i.get_line_number() ); 
        tokens_created.push_back( Token ( SCHEMES, word_value, i.get_line_number() )); 
    //    cout << "(" << "SCHEMES,\"" << word_value << "\"," << i.get_line_number() << ")\n"; 
        number_of_tokens++;
        return;
    }
    
    else if (word_value == "Facts")
    {
        Token( FACTS, word_value, i.get_line_number() ); 
        tokens_created.push_back( Token ( FACTS, word_value, i.get_line_number() )); 
    //    cout << "(" << "FACTS,\"" << word_value << "\"," << i.get_line_number() << ")\n"; 
        number_of_tokens++;
        return;
    }
    
    else if (word_value == "Rules")
    {
        Token( RULES, word_value, i.get_line_number() ); 
        tokens_created.push_back( Token ( RULES, word_value, i.get_line_number() )); 
    //    cout << "(" << "RULES,\"" << word_value << "\"," << i.get_line_number() << ")\n"; 
        number_of_tokens++;
        return;
    }
    
    else if (word_value == "Queries")
    {
        Token( QUERIES, word_value, i.get_line_number() ); 
        tokens_created.push_back( Token ( QUERIES, word_value, i.get_line_number() )); 
    //    cout << "(" << "QUERIES,\"" << word_value << "\"," << i.get_line_number() << ")\n"; 
        number_of_tokens++;
        return;
    }
    
    else // has to be an ID 
    {
        Token( ID, word_value, i.get_line_number() ); 
        tokens_created.push_back( Token ( ID, word_value, i.get_line_number() )); 
    //    cout << "(" << "ID,\"" << word_value << "\"," << i.get_line_number() << ")\n"; 
        number_of_tokens++;
        return;
    }
    
    
    
}



/*
//NOTES            

 
 
*/