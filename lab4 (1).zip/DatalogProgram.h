#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include <set> 
#include "Predicate.h"
#include "Rule.h"
#include "Parameter.h"

using namespace std;


class DatalogProgram
{
    private:
        vector<Predicate> schemes;
        vector<Predicate> facts;
        vector<Predicate> queries;
        vector<Rule> rules; 
        set<string> domain; 
        Predicate p; 
        Rule r; 
        
        
        
    public:
        void addScheme(Predicate pred);
        void addFact(Predicate pred);
        void addQuery(Predicate pred);
        void addDomain( string domain_value); 
        void addRule(Rule r);
        
        void printScheme();
        void printFact();
        void printRule(); 
        void printQuery();
        void printDomain();

        vector<Predicate> get_schemes_vector();
        vector<Predicate> get_facts_vector();
        vector<Predicate> get_queries_vector();
        vector<Rule> get_rules_vector(); 

};


