#include "Token.h"

using namespace std;

Token::Token(TokenType token_type, string token_value, int token_line_number)
{
    value = token_value;
    line_number = token_line_number;
    type = token_type; 
    
    /*
    if (! is_map_init)
    {
        init_map();
        is_map_init = true; 
    }*/
}
/*
void Token:: init_map()
{// used for printing
     
        
}
*/

TokenType Token:: get_TokenType()
{
    return type; 
}

string Token:: get_TokenValue()
{
    return value; 
}

int Token:: get_TokenLineNum()
{
    return line_number; 
}