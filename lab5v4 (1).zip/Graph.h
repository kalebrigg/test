#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include <stack>
#include "Node.h"



using namespace std;

       
class Graph 
{
    private:
       map< int, Node > graph_of_nodes;
       stack<int> beginning_stack; 
       set<int> SCC; 
       vector<set<int> > all_SCC; 
     
        
    public:
       Node& get_Node( int num); 
       void insert_into( int node_number, int receiveing_num);
       
       void DFSforest(); 
       void DFSforest2( stack<int> new_stack ); 
       void DFSreverse( int index);
       void DFSforward( int index);
       
       
       void dependency_toString(); 
       void print_stack();
       void print_set(); 
       
       bool is_dependent( int i );
       
       stack<int> getStack(); 
       vector<set<int> >  get_all_SCC(); 
       
};


