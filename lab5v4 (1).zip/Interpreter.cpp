#include "Interpreter.h"

using namespace std;

Interpreter:: Interpreter( DatalogProgram in)
{
    mydata = in;
}

void Interpreter:: make_relation()
{
    
    
    
    for ( unsigned int i = 0; i < mydata.get_schemes_vector().size(); i++ )
    {
        Scheme s;   // should this be reset everytime?
        
        string n = mydata.get_schemes_vector()[i].get_headID(); 
        
        for ( unsigned int j = 0; j < mydata.get_schemes_vector()[i].get_param_vector().size(); j++)
        {
            
            string p = mydata.get_schemes_vector()[i].get_param_vector()[j]->get_param_value(); 
            s.push_back(p); 
        }
        
        
        
        datab.insert(pair<string, Relation>( n , Relation( n , s) ));
        //datab[n].print_scheme_vec(); 
        
    }
    
    //cout << "--------------------------------" << endl; 
    
        
}

void Interpreter:: fill_relation()
{
    
    
   // Tuple t;
    
    for( unsigned int i = 0; i < mydata.get_facts_vector().size(); i++)
    {
        Tuple t;// should this be reset everytime?? 
        
        string n = mydata.get_facts_vector()[i].get_headID(); 
        
        for ( unsigned int j = 0; j < mydata.get_facts_vector()[i].get_param_vector().size(); j++)
        {
            string p = mydata.get_facts_vector()[i].get_param_vector()[j]->get_param_value();
            t.push_back(p); 
            //cout << t.at(j) << endl; 
        }
        
        datab[n].add_tuple( t ); 
        //datab[n].print_rows(); 
    }
    
    
}



void Interpreter:: evaluate_queries()
{
    bool query = true; 
    cout<< endl << "Query Evaluation" << endl; 
    
    for (unsigned int i = 0; i < mydata.get_queries_vector().size(); i++ )
    {
        
        Relation R = evaluate_predicate( mydata.get_queries_vector()[i], query );
        
    }
    
    
}

Relation Interpreter:: evaluate_predicate( Predicate p , bool is_q )
{
    map<string,int> firstVar; 
    vector<int> ColsToKeep; 
    Scheme renameScheme; 
    
    Relation R1 = datab[ p.get_headID() ];
    
    for (unsigned int i = 0; i < p.get_param_vector().size(); i++ )
    {
        
        if ( p.get_param_vector()[i]->getPtype() == ParamType::param_STRING    )//FIX 
        {
            R1 = R1.select1( p.get_param_vector()[i]->get_param_value() , i );   // select 1
        }
        
        else
        {
            if (firstVar.find( p.get_param_vector()[i]->get_param_value()  ) == firstVar.end() )
            {
                
                firstVar.insert(pair<string, int>( p.get_param_vector()[i]->get_param_value() , i ));
                ColsToKeep.push_back( i );
                renameScheme.push_back( p.get_param_vector()[i]->get_param_value() );
                
            }
            else
            {
                auto it = firstVar.find( p.get_param_vector()[i]->get_param_value() );
                 R1 = R1.select2( i , it->second );
            }
            
        }
        
    }
    
    R1 = R1.project( ColsToKeep );
    R1 = R1.re_name( renameScheme);
    
    //R1.print_scheme_vec();
    //R1.print_rows(); 
    
    if (is_q)
    {
        
        R1.query_tostring( p ); 
    }
    
    return R1; 
    // put the to-string in a dif funciton, pass in relation 
}

void Interpreter:: evaluate_all_rules()
{
    bool relation_changed;
    bool temp_bool; 
    int passes; 
    //string tempstring; 

    cout << "Rule Evaluation" << endl; 
    
    
    for (  set<int> SCC : fg.get_all_SCC()   )  //  loop through vector
    {      
        /*
        tempstring = "";
        cout << "SCC: "; 
        for( int i : SCC)
        {
            tempstring += "R" + to_string(i) + ",";
        }
        tempstring.pop_back(); 
        cout << tempstring << endl; 
        tempstring = ""; */
        
        print_SCC( SCC  ); 
        
        passes = 0;
        
       
        
        
        do
        {
            relation_changed = false; 
             
            
            for( int i : SCC )                      // each position in that set 
            {
                if ( SCC.size() == 1 )
                {
                    if ( !fg.is_dependent( i )  ) 
                    {
                        temp_bool = evaluate_rule( mydata.get_rules_vector()[i] );
                        relation_changed = false; 
                         
                    }
                    else
                    {
                        
                        
                        temp_bool = evaluate_rule( mydata.get_rules_vector()[i] );
            
                        if (temp_bool)
                        {
                            relation_changed = true; 
                            // cout << "ENTER" << endl; 
                        }
                    }
                
                }
                else
                {
                    

                    temp_bool = evaluate_rule( mydata.get_rules_vector()[i] );
            
                    if (temp_bool)
                    {
                        relation_changed = true; 
                        // cout << "ENTER" << endl; 
                    }
                }
                    
            }
            
            passes++; 
                
        } while ( relation_changed == true );
        
        print_passes( SCC, passes );
        
        /*
        cout << passes << " passes: ";
        tempstring = "";
        for( int i : SCC)
        {
            tempstring += "R" + to_string(i) + ",";
        } 
        tempstring.pop_back();
        cout << tempstring << endl; 
        */
    } 
    
    
    
    //LAB 4 FIXED POINT ALGORITHM//
    /*
    bool relation_changed;
    bool temp_bool; 
    int passes = 0; 
    
    cout << "Rule Evaluation" << endl; 
    
    do
    {
        relation_changed = false;
        
        
        for (unsigned int i = 0; i < mydata.get_rules_vector().size(); i++ )  //  loop through vector
        {                                                                     // each position in that set 
            
            temp_bool = evaluate_rule( mydata.get_rules_vector()[i] );
            
            if (temp_bool)
            {
                relation_changed = true; 
                // cout << "ENTER" << endl; 
            }
            
        }
        
        passes++; 
        // cout << "Passes is incremented" << endl; 
        
    } while ( relation_changed == true );
    
    cout << endl << "Schemes populated after " << passes << " passes through the Rules." << endl << endl;  
    */
}

bool Interpreter:: evaluate_rule( Rule r )
{
    bool relation_changed = false; 
    bool is_q = false; 
    
    Relation current_rel = evaluate_predicate( r.get_rule_predicates_vector()[ 0 ], is_q ); 
    // cout << "START JOIN" << endl; 
    
    for( unsigned int i = 1; i < r.get_rule_predicates_vector().size(); i++)
    {
        
        Relation temp_rel = evaluate_predicate( r.get_rule_predicates_vector()[ i ], is_q ); 
        current_rel = current_rel.join( temp_rel ); 
        // cout << "JOIN " << endl; 
        
    }
    
    // cout << "FINISH JOINING" << endl; 
    
    vector<int> projected_columns; 
    
    for( unsigned int i = 0; i < r.get_headpredicate().get_param_vector().size(); i++ )
    {
        for ( unsigned int j = 0; j < current_rel.return_schemes().size(); j++  )
        {
            
            if ( r.get_headpredicate().get_param_vector()[i]->get_param_value() ==  current_rel.return_schemes()[j] )
            {
                // cout << "match found" << endl; 
                projected_columns.push_back( j ); 
                //cout << "J: : " << j << endl; 
                
            }
        }
    }
    
    // cout << "Start PROJECTED " << endl; 
    
    //current_rel.print_rows(); 
    //current_rel.print_scheme_vec(); 
    
    current_rel = current_rel.project( projected_columns ); 
    // current_rel.print_scheme_vec();
    // current_rel.print_rows(); 
    // cout << "----------------------------------" << endl;  
    
    // cout << "Finishing PROJECTED " << endl; 
      
    r.rule_toString();
    
    relation_changed = datab[ r.get_headpredicate().get_headID() ].union_function( current_rel ); 
    //  datab[ r.get_headpredicate().get_headID() ].print_scheme_vec(); 
    //  datab[ r.get_headpredicate().get_headID() ].print_rows(); 
    
    return relation_changed; 
}


void Interpreter:: create_graph()
{
    
    for ( unsigned int i = 0; i < mydata.get_rules_vector().size(); i++  ) //rules
    {
       fg.get_Node( i );
       
       
        for ( unsigned int j = 0; j < mydata.get_rules_vector()[i].get_rule_predicates_vector().size(); j++  ) // loop each predicate
        {
            
            for ( unsigned int k = 0; k < mydata.get_rules_vector().size(); k++ ) //  rules again 
            {
                rg.get_Node( k );
                
                if ( mydata.get_rules_vector()[k].get_headpredicate().get_headID() == mydata.get_rules_vector()[i].get_rule_predicates_vector()[j].get_headID() ) 
                {
                    
                    fg.insert_into( i, k );
                    
                    rg.insert_into( k , i );
                    
                }
            }
        }
    }
    
    fg.dependency_toString();           //Part 1
    
    //cout << "Reverse ";                 //Part 2
    //rg.dependency_toString(); 
    
    
    rg.DFSforest();                     //Part 3
    //cout << "FINISH REVERSE" << endl;  
    //  rg.print_stack(); 
    
    
    fg.DFSforest2(   rg.getStack()  );                   //Part 4
    //cout << "FINISH FORWARD" << endl; 
    //fg.print_set(); 
    
    
    
    
    
    // depth first search on reverse graph 
    // depth first search on forward graph according to reverse 
    
}

void Interpreter:: print_SCC( set<int> SCC  )
{
    string tempstring = "";
    cout << "SCC: "; 
    
    for( int i : SCC)
    {
        tempstring += "R" + to_string(i) + ",";
    }
    tempstring.pop_back(); 
    cout << tempstring << endl; 
    
    tempstring = "";
}

void Interpreter:: print_passes( set<int> SCC, int passes )
{
    cout << passes << " passes: ";
    string tempstring = "";
    
    for( int i : SCC)
    {
        tempstring += "R" + to_string(i) + ",";
    } 
    tempstring.pop_back();
    cout << tempstring << endl; 
}







/*
       NOTES: 
       
       Steps:

	1. Make a forward graph
	2. Reverse graph ( copy ) 
	3. DFS reverse( this gives a post order traversal) 
    4. DFS forward ( according to the post order traversal )
       
      REMEMBER SPECIAL CASE.. if it doesnt depend on itself or anything else
      
       
       
*/












void Interpreter:: test_func1() 
{ 
    vector<int> ints = { 1, 2 };
    Scheme s;
    s.push_back("X");
    s.push_back("Y");
    
    datab["SK"].print_scheme_vec();
    datab["SK"].print_rows();
    cout << "-------------" << endl; 
    
    Relation R1 = datab["SK"].select1( "\'1\'" , 0 );
    R1.print_scheme_vec(); 
    R1.print_rows(); 
    cout << "----------------------First Select" << endl; 
    
    Relation R2 = R1.select2( 1, 3 );
    R2.print_scheme_vec(); 
    R2.print_rows(); 
    cout << "----------------------Second Select" << endl; 
    
    Relation R3 = R2.project( ints );
    R3.print_scheme_vec(); 
    R3.print_rows(); 
    cout << "----------------------Project" << endl; 
    
    Relation R4 = R3.re_name( s );
    R4.print_scheme_vec(); 
    R4.print_rows(); 
    cout << "----------------------Rename" << endl; 
    
    
}

void Interpreter:: test_func2() 
{ 
    
    vector<int> ints; 
    ints.push_back( 4 );
    ints.push_back( 1 );
    
    
    
    cout << "STARTING" << endl; 

     Relation R1 = datab["snap"].join( datab["csg"]  );
     
     cout << "FINISHING JOIN" << endl; 
     R1.print_scheme_vec(); 
     R1.print_rows(); 
     
     cout<< "--------------------------------------relations joined" << endl; 
     
     R1 = R1.project( ints );
     R1.print_scheme_vec();
     R1.print_rows(); 
     
     cout << "---------------------------------------projected" << endl; 
     
     datab["cn"].union_function( R1 );
     datab["cn"].print_scheme_vec();
     datab["cn"].print_rows(); 
     
     
}