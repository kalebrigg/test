#include "DatalogProgram.h"

using namespace std; 

void DatalogProgram:: addScheme(Predicate pred)
{
    schemes.push_back( pred );
}

void DatalogProgram:: addFact(Predicate pred )
{
    facts.push_back( pred );
}

void DatalogProgram:: addQuery(Predicate pred )
{
    queries.push_back( pred ); 
}

void DatalogProgram:: addDomain( string domain_value)
{
    domain.insert( domain_value);
}

void DatalogProgram:: addRule( Rule r)
{
    rules.push_back( r );
}
////////////////////////////////////////////////////////////////////////////////////////
///   PRINTING

void DatalogProgram:: printScheme()
{
    cout << "Schemes(" << schemes.size() << "):" << endl;
    
    for( Predicate pred : schemes )
    {
        //cout << type_of_token.at( tok.get_TokenType() ) << ", " << tok.get_TokenValue() << ", " << tok.get_TokenLineNum() << "." << endl; 
        //cout << pred.get_headID() << "(";
        
        cout << pred.toString();
        
        
        
        cout << ")" << endl; 
    }  
    
    
    
    
    
}
void DatalogProgram:: printFact()
{
    cout << "Facts(" << facts.size() << "):" << endl;
    
    for( Predicate pred : facts )
    {

         cout << pred.toString();
        
         cout << ")." << endl; 
    }
    
    
}
void DatalogProgram:: printRule()
{
    cout << "Rules(" << rules.size() << "):" << endl;
    
    for( Rule r : rules )
    {
        r.rule_toString(); 
          
    }
    
    
    
}
void DatalogProgram:: printQuery()
{
    cout << "Queries(" << queries.size() << "):" << endl; 
    
    for( Predicate pred : queries )
    {

         cout << pred.toString();
        
         cout << ")?" << endl; 
    }
}






void DatalogProgram:: printDomain()
{
    cout << "Domain(" << domain.size() << "):" << endl; 
    
    for (std::set<string>:: iterator it=domain.begin(); it!=domain.end(); ++it)
    {
        cout << *it << endl; 
    }
}

vector<Predicate> DatalogProgram:: get_schemes_vector()
{
    return schemes; 
}

vector<Predicate> DatalogProgram:: get_facts_vector()
{
    return facts; 
}

vector<Predicate> DatalogProgram:: get_queries_vector()
{
    return queries; 
}

vector<Rule> DatalogProgram:: get_rules_vector()
{
    return rules; 
}