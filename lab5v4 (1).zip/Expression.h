#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "Parameter.h"


using namespace std;


class Expression : public Parameter
{
    private:
        Parameter* left;
        string op;   // is this a key word/reserved in library or what 
        Parameter* right; 
        
        // ((x+y)Z) 
    public:
        Expression(); 
        ~Expression();
        Expression( Parameter* leftt, string opp , Parameter* rightt); 
        void set_operator( string string_operator ); 
        string get_operator(); 
        
        virtual string param_toString(); 
        
        void clear();
};


