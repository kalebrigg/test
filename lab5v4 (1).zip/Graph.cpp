#include "Graph.h"

using namespace std;
       
Node& Graph:: get_Node( int num)
{
    return graph_of_nodes[ num ];
}

void Graph:: insert_into( int node_number, int receiveing_num)
{
    graph_of_nodes[node_number].insert( receiveing_num); 
    graph_of_nodes[node_number].set_index( node_number ); 
}

void Graph:: DFSforest()
{
    
    for ( auto m : graph_of_nodes)
    {
        DFSreverse( m.first ); //passing in the index;
    }
    
    
    
    
    for ( auto m : graph_of_nodes)
    {
        get_Node(m.first).setflag( false );
    }
    //need to reset back to false 
}

void Graph:: DFSforest2( stack<int> new_stack )
{
    //cout << "START FORWARD" << endl; 
    
    // cout << "EMPTY : " << new_stack.empty() << endl; 
    /*
    for ( auto s : new_stack )
    {
        //cout << "about to start" << endl; 
        DFSforward( s );
        
        
        if ( !SCC.empty() )
        {  
            cout << "ENTER" << endl; 
            all_SCC.push_back( SCC ); 
        
            SCC.clear(); 
        }
        
        
        all_SCC.push_back( SCC );
        cout << "pushing into vector of sets" << endl; 
        SCC.clear(); 
    }
    cout << "doing nothing" << endl; 
    */
    while (!new_stack.empty())
    {
         
        DFSforward( new_stack.top() );
        
        if ( !SCC.empty() )
        {  
            // cout << "push into vector of set" << endl; 
            all_SCC.push_back( SCC ); 
        
            SCC.clear(); 
            
        }
        new_stack.pop(); 
       
    }
    
    // reset?? 
}

void Graph:: DFSreverse( int index)
{
    // cout << "START REVERSE" << endl; 
    
     if ( get_Node( index ).checkflag() == false )
     {
        // cout << "Node index: " << get_Node( index ).get_node_index() << " is " << get_Node( index ).checkflag() << endl; 
        
        get_Node( index ).setflag( true );
        
        // cout << "Node index: " << get_Node( index ).get_node_index() << " is " << get_Node( index ).checkflag() << endl; 
        
        for ( auto n : get_Node(index) )
        {
            DFSreverse(  n  );
        }
            
        beginning_stack.push( index ); 
        // cout << "PUSH" << endl; 
     }
    //  cout << "FINISH ONE NODE" << endl; 
}


void Graph:: DFSforward( int index  )
{
    
    if ( get_Node(index).checkflag() == false )
     {
         get_Node(index).setflag( true ); 
        
         for ( auto n : get_Node(index) )
         {
             DFSforward( n  ); 
         }
        
         SCC.insert( index );
        //  cout << "Pushed to set" << endl; 
     }
     
    
    
}

void Graph:: dependency_toString()
{ 
    /*
    cout << "Dependency Graph" << endl; 
    string str;
    
    for ( auto d : graph_of_nodes )
    {
        // cout << "START" << endl; 
        cout << "R" << d.first << ": " ; 
        
        if ( !d.second.empty() )
        {
            // cout << "GO IN : "; 
            
            for ( auto n : d.second )
            {
                cout << "R" << n << " "; 
            }
        }
        
        
        cout << endl; 
    }
    
    cout << endl;
    */
    
    cout << "Dependency Graph" << endl; 
   
    
    for ( auto d : graph_of_nodes )
    {
        // cout << "START" << endl; 
        cout << "R" << d.first << ":" ; 
        string str;
        
        if ( !d.second.empty() )
        {
            // cout << "GO IN : "; 
            
            for ( int n : d.second )
            {
                //cout << "R" << n << ", "; 
                str +=  "R" + to_string(n) + ",";
                
            }
            str.pop_back();
            cout << str;  
        }
        
        
        cout << endl; 
    }
    
    cout << endl;
}

void Graph:: print_stack()
{
    /*
    for ( auto s : stack )
    {
        cout << s << ", ";
    }
    cout << endl << endl; 
    */
    
    while (!beginning_stack.empty() )
    {
        cout << beginning_stack.top() << ", ";
        beginning_stack.pop();
    }
    cout << endl << endl; 

}

void Graph:: print_set()
{
    for ( set<int> SCC: all_SCC)
    {
        for( int i : SCC)
        {
            cout << i << ", ";
        }
        cout << endl; 
    }
    cout << endl << endl; 
}

stack<int> Graph:: getStack()
{
    return beginning_stack; 
}

vector<set<int> > Graph:: get_all_SCC()
{
    return all_SCC; 
}

bool Graph:: is_dependent( int i)
{
    bool b;
    
    for ( int val : graph_of_nodes[i] )
    {
        if ( val == i )
        {
            b = true; 
        }
    }
    
    
    return b;
}