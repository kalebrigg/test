#include "Node.h"

using namespace std;

void Node:: set_index( int node_number)
{
    node_index = node_number;
}

int Node:: get_node_index()
{
    return node_index; 
}

void Node:: setflag( bool t )
{
    flag_visited = t; 
}

bool Node:: checkflag()
{
    return flag_visited; 
}