#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include <set> 



using namespace std;


class Node: public set<int> 
{
    private:
        int node_index;
        bool flag_visited;
        
    public:
         Node()
         {
             flag_visited = false; 
         }

         
         void set_index( int node_number ); 
         int get_node_index(); 
        
         void setflag( bool t );
         bool checkflag();
        
};


