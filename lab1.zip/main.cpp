#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <map>
#include "Token.h"
#include "InputReader.h"
#include "Scanner.h"
 
using namespace std;

int main(int argc,  char* argv[])
{
// call read file function 
 
  Scanner s; 

  
  s.create_token( argv[1]); 

  
  
    return 0;
}



/*  QUESTIONS/PROBLEMS


*/