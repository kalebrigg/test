#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>
#include "Token.h"

using namespace std;

class InputReader
{
    private:
        char c; 
        int token_line_number; 
        ifstream data_file;
        
    public:
        InputReader(); 
        void read_file( string file_name); 
        int get_line_number(); 
        char get_character();
        char get_character_with_space();
        bool eof_check();
        char peek_char();

};
