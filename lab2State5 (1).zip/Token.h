#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>

using namespace std;

enum TokenType 
{
        COMMA, PERIOD, Q_MARK, LEFT_PAREN, RIGHT_PAREN, COLON,
        COLON_DASH, MULTIPLY, ADD, SCHEMES, FACTS, RULES, QUERIES,
        ID, STRING, COMMENT, UNDEFINED, ENDOFFILE
        
}; 

static map<TokenType, string> type_of_token = { {COMMA,"COMMA"}, {PERIOD,"PERIOD"}, {Q_MARK,"Q_MARK"}, {LEFT_PAREN,"LEFT_PAREN"}, {RIGHT_PAREN,"RIGHT_PAREN"}, {COLON,"COLON"},{COLON_DASH,"COLON_DASH"},
        {MULTIPLY,"MULTIPLY"},{ADD,"ADD"},{SCHEMES,"SCHEMES"},{FACTS,"FACTS"},{RULES,"RULES"}, {QUERIES,"QUERIES"},{ID,"ID"}, {STRING,"STRING"}, {COMMENT,"COMMENT"},{UNDEFINED,"UNDEFINED"},{ENDOFFILE,"EOF"} };



class Token
{
    private:
        string value; 
        int line_number; 
        TokenType type; 
        
     //   static bool is_map_init = false;
        /*
         
       

*/
        
    public:
        Token( TokenType token_type, string token_value, int token_line_number ); 
        
        TokenType get_TokenType(); 
        string get_TokenValue(); 
        int get_TokenLineNum(); 
    
      //  void init_map(); 
};


