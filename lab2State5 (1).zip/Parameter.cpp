#include "Parameter.h"

using namespace std; 

Parameter:: Parameter()
{
    
}

Parameter:: ~Parameter()
{
    
}

Parameter::Parameter( string value, TokenType type)
{
    string_value = value;
    ptype = (ParamType) type;
  
}

void Parameter:: isID()
{
     
    
}

string Parameter:: get_param_value()
{
    return string_value; 
    
}

string Parameter:: param_toString()
{
    return string_value;
}

void Parameter:: clear()
{
    
}

/*
~Parameter:: Parameter()
{
    
}
*/