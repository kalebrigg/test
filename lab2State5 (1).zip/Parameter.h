#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "Token.h"

using namespace std;

enum ParamType 
{
        param_ID = ID,
        param_STRING = STRING, 
        
};

class Parameter
{
    private:
        string string_value; 
        ParamType ptype; 
        
        
        
    public:
        Parameter(); 
        virtual  ~Parameter(); 
        Parameter( string value, TokenType type); 
        
        string get_param_value(); 
        virtual string param_toString();
        
        virtual void clear();
        
        void isID();
};


