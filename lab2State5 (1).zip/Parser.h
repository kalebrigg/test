#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "Scanner.h"
#include "Predicate.h"
#include "Parameter.h"
#include "DatalogProgram.h"
#include "Rule.h"
#include "Expression.h"


using namespace std;


class Parser
{
    private:
        int index; 
        vector <Token> vector_of_tokens; 
        Predicate temp; 
        Parameter* temp2;
        Rule temp3; 
        DatalogProgram data; 
        Expression op; 
       
        vector <Parameter*> vec_of_ex; 
     
        
    public:
        Parser( vector<Token> my_vector); 
        
        void parse(); 
        void match(TokenType expected_token ); 
        Token get_next_token();
        
        void scheme();   
    	void schemeList();
    	
    	void fact(); 
    	void factList(); 
    	
    	void rule(); 
    	void ruleList(); 
    	
    	
    	void query();
    	void queryList();
        
        void headPredicate(); 
        void predicate(); 
        void predicateList();
        
        void idList(); 
        void stringList(); 
        
        Parameter* parameter();
        //void parameter(); 
        void parameterList(); 
       
        Expression* expression();
        //void expression();
        string operator_function();
       
        void check_vector(); 
        
        void delete_scheme(); 
        void delete_fact(); 
        void delete_rule(); 
        void delete_queries(); 
        
        void extra_deleting(); 
        
};


