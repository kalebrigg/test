#include "InputReader.h"

using namespace std;

InputReader:: InputReader()
{
    token_line_number = 1; 
}

void InputReader:: read_file( string file_name)
{
 //   ifstream data_file;
    data_file.open(file_name);
  

  ///  data_file.close(); 
}

int InputReader:: get_line_number()
{
    return token_line_number; 
}

char InputReader:: get_character()
{
    c = data_file.get();
   // cout << "C input test: " << c << endl; 
    
    while (isspace(c))
    {
 //       cout << "C is a space" << endl; 
        if (c == '\n')
            token_line_number++;
            
        c = data_file.get(); 
    }
    
    if (c == '\n')
        token_line_number++; 
    
      
       
    return c; 
}

bool InputReader:: eof_check()
{
    return data_file.eof(); 
}

char InputReader:: peek_char()
{
    return data_file.peek();
}

char InputReader:: get_character_with_space()
{
    c = data_file.get();
   // cout << "C input test: " << c << endl; 
    
    if (c == '\n')
        token_line_number++; 
      
       
    return c; 
}