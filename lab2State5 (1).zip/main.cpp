#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <map>
#include "Token.h"
#include "InputReader.h"
#include "Scanner.h"
#include "Parser.h"
 
using namespace std;

int main(int argc,  char* argv[])
{
// call read file function 
 
  Scanner s; 

  vector<Token> my_vector = s.create_token( argv[1]); 
  
  Parser p = Parser(my_vector);
  p.parse();
  
  
    return 0;
}



/*  QUESTIONS/PROBLEMS


*/