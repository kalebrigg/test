#include "Predicate.h"

using namespace std; 


//Predicate:: ~Predicate()
//{
    /*
    while ( parameters.size() != 0 )
    {
        
    }
    */
    /*
    for ( Parameter* p : parameters )
    {
        delete p;
    }
    */
//}


void Predicate:: setHeadID(string head_ID)
{
     headID = head_ID; 
   //  cout << "HeadID is: " << headID << endl; 
}

void Predicate:: addParam( Parameter* parameter_value )
{
    parameters.push_back(parameter_value);
   // parameters.push_back(Parameter)
}


void Predicate:: clear_vector_param()
{
    /*
    for ( Parameter* p : parameters )
    {
        delete p;
    }
    */
    parameters.clear(); 
}

string Predicate:: get_headID()
{
    return headID; 
}

vector<Parameter*> Predicate:: get_param_vector()
{
    return parameters; 
}

string Predicate:: toString() {
    cout << headID << "(";
    string temporary_string;
   
    for (Parameter* param: parameters)
    {
        temporary_string += param->param_toString();
        temporary_string += ","; 
    }
    temporary_string.pop_back(); 
    return temporary_string; 
}

