#include "Parser.h"

using namespace std; 

Parser::Parser( vector<Token> my_vector)
{
    for( Token tok : my_vector)
    {
       if (tok.get_TokenType() != COMMENT)
            vector_of_tokens.push_back(tok);
    }
    
    
    index = 0; 
    
    
}
void Parser:: parse()
{

    try
    {
        //cout << "START:" << endl; 
    
    	match (SCHEMES);
    	match(COLON); 
    	scheme();   
    	schemeList();
    	//cout << "   DONE WITH ALL SCHEMES" << endl; 
    	
    	match(FACTS);
    	match(COLON);
    	factList(); 
    	//cout << "   DONE WITH ALL FACTS" << endl; 
    	
    	match(RULES);
    	match(COLON);
    	ruleList(); 
    	//cout << "Done with Rules" << endl; 
    	
    	match(QUERIES);
    	match(COLON);
    	query();
    	queryList();
    	//cout << "Done with Queries" << endl; 
    	
    	match(ENDOFFILE);  
    	
    	cout << "Success!" << endl; 
    	
    	data.printScheme();
    	delete_scheme(); 
    	
    	data.printFact();
    	delete_fact();
    	
    	
    	data.printRule();
    	delete_rule(); 
    
    
    	data.printQuery();
    	delete_queries(); 
    	
    	
    	data.printDomain();
    	
    	for ( auto a : vec_of_ex )
        {
    //            cout << "Ex: " << a->param_toString() << endl;

        a->clear(); 
        delete a; 
        }
    
    	
    	
	
	} catch ( Token BadToken )  
	    {
	        cout << "Failure!" << endl; 
	        cout << "(" << type_of_token.at( get_next_token().get_TokenType() ) <<",\"" << BadToken.get_TokenValue() << "\"," << BadToken.get_TokenLineNum() << ")" << endl;
	        
	       //  cout << "scheme" << endl; 
	        delete_scheme();
	       //  cout << "scheme" << endl;
            delete_fact(); 
            //  cout << "scheme" << endl;
            delete_rule(); 
            // cout << "scheme" << endl;
            delete_queries(); 
            // cout << "scheme" << endl;
	        
	       //                                                     HasSameAddress(X,Y) :- snap(A),snap( (x Y) ).
	       
            extra_deleting();
	    }

    

}

void Parser:: match(TokenType expected_token)
{
 
    TokenType current_token = vector_of_tokens.at(index).get_TokenType(); 
   // cout << "Expected Token is " << expected_token << " and is being compared to " << current_token << ". " << endl; 
    
    
    if ( expected_token == current_token ) 
    {
        index++;
        //return value; ??
        return; 
    }
    else
    {
       // cout << "about to throw" << endl; 
        throw vector_of_tokens.at(index); 
    }
    
}

Token Parser:: get_next_token()
{
    Token next_token = vector_of_tokens.at(index); 
  //  cout << "NEXT TOKEN IS: " << next_token << endl;
    return next_token; 
    
    
    //return vector_of_tokens.at(index); 
}


//////////////////////////////////////////////////////////     GRAMMARS      ////////////////////////////////////////////////////////


void Parser:: scheme()
{
    headPredicate(); 
    
    data.addScheme( temp );
	temp.clear_vector_param();
	
	
}

void Parser:: headPredicate()
{
     
    temp.setHeadID(get_next_token().get_TokenValue());
    match (ID);

	match (LEFT_PAREN); 
	
	temp2 = new Parameter( get_next_token().get_TokenValue() , get_next_token().get_TokenType() );
    temp.addParam(temp2); 
	match(ID);

	idList();

	match (RIGHT_PAREN);

	//do i need to delete temp? 
	
	//remember to clear vector to use later 
	//   this clears vector of parameters temp.clear_vector_param();
	// add predicate to program
    // program -> vector 
    
    
}

void Parser:: idList()
{
      
 //   cout << "start ID list func" << endl; 
    if ( get_next_token().get_TokenType() == COMMA)
    {
 //       cout << "enter loop" << endl; 
        match(COMMA);
     
        temp2 = new Parameter( get_next_token().get_TokenValue() , get_next_token().get_TokenType() );
        temp.addParam(temp2);
        match(ID); 
      
        idList();
    }
    else
        return; //lambda
    
    
    
    
}

void Parser:: schemeList()
{
    
    
    
    if ( get_next_token().get_TokenType() == ID)
    {
        scheme();
        schemeList(); 
    }
    else
        return; // lambda
    
    
    
}

void Parser:: factList()
{
    
    
    if ( get_next_token().get_TokenType() == ID )
    {
        temp.setHeadID(get_next_token().get_TokenValue());
        match(ID);
        fact();
        factList();
    }
    else
        return; //lambda
       
        
    
}

void Parser:: fact()
{

    match(LEFT_PAREN);
    
    
    temp2 = new Parameter( get_next_token().get_TokenValue() , get_next_token().get_TokenType() );
    temp.addParam(temp2);
    data.addDomain( get_next_token().get_TokenValue() ); 
    match(STRING); 
    
    
    stringList(); 
    
    match(RIGHT_PAREN);
    match(PERIOD);
    
    data.addFact( temp );
	temp.clear_vector_param();
	//do i need to delete temp?
	
	//remember to clear vector to use later 
	//   this clears vector of parameters temp.clear_vector_param();
	// add predicate to program
    // program -> vector 
    
}

void Parser:: stringList()
{
    
    
    if ( get_next_token().get_TokenType() == COMMA)
    {
        match(COMMA);
        
        temp2 = new Parameter( get_next_token().get_TokenValue() , get_next_token().get_TokenType() );
        temp.addParam(temp2);
        data.addDomain( get_next_token().get_TokenValue() ); 

        match(STRING);
        
        stringList();
    }
    
    else
        return; //lambda
    
    
}


void Parser:: ruleList()    // not finished
{
    
    if ( get_next_token().get_TokenType() == ID  )
    {
        rule();
        ruleList(); 
    }
    else
        return; //lambda
       
    
}

void Parser:: rule()
{
    headPredicate();
    temp3.setHeadPred(temp);
    temp.clear_vector_param();
    
    
    match(COLON_DASH);
    
    predicate();
    temp3.addpredicate(temp);
    //clear
    temp.clear_vector_param();
   
   
    predicateList();
    match(PERIOD);
    
    data.addRule( temp3 );
    temp3.clear_rule_predicates();
    temp3.clear_headpred_param(); 
    temp.clear_vector_param(); 
    //done with all of rule and now im adding Rule 
    
}



void Parser:: predicate()
{
    
    temp.setHeadID(get_next_token().get_TokenValue());
    match(ID);
    
    match(LEFT_PAREN);
    
    temp.addParam( parameter() ); 
    
    
    parameterList(); 
    
    match(RIGHT_PAREN);
    
    
    
    
    
}

void Parser:: predicateList()
{
    if ( get_next_token().get_TokenType() == COMMA)
    {
        match(COMMA);
        predicate();
        temp3.addpredicate(temp);
        //clear  
        temp.clear_vector_param();
        
        
        predicateList();
        
    }
    else
        return; //lambda
}

Parameter* Parser:: parameter()
{
    if ( get_next_token().get_TokenType() == STRING )
    {
        //temp2 = Parameter( get_next_token().get_TokenValue() , get_next_token().get_TokenType() );
        //temp.addParam(temp2); 
        Parameter* p = new Parameter( get_next_token().get_TokenValue() , get_next_token().get_TokenType() );
        //temp.addParam( p ); 
            
        match(STRING);
         return p; 
        
    }
   
    else if ( get_next_token().get_TokenType() == ID)
    {
        
        //temp2 = Parameter( get_next_token().get_TokenValue() , get_next_token().get_TokenType() );
        //temp.addParam(temp2); 
         Parameter* p = new Parameter( get_next_token().get_TokenValue() , get_next_token().get_TokenType() );
         //temp.addParam( p ); 
        
        match(ID);
         return p; 
    }
   
    else
    {
        return expression();
    }
        
         
       
    
}

Expression* Parser:: expression()
{
    
    match(LEFT_PAREN);
    
    Parameter* left = parameter();
    vec_of_ex.push_back(left);
    
    string op = operator_function();   // need to add whatever the operator is 
    
    Parameter* right = parameter();
    vec_of_ex.push_back(right);
    
    Expression* e = new Expression (left, op , right);
    
    
    match(RIGHT_PAREN);
    return e;
}


string Parser:: operator_function()
{
    if (get_next_token().get_TokenType() == ADD)
    {
        string result =  get_next_token().get_TokenValue() ;
        match(ADD);
        return result; 
    }
    
    else
    {
        string result =  get_next_token().get_TokenValue();
        match(MULTIPLY);
        return result; 
    }
    
}



void Parser:: parameterList()
{
    if( get_next_token().get_TokenType() == COMMA)
    {
        match(COMMA);
        
         temp.addParam(  parameter() );
        parameterList();
    }
    else
        return; //lambda
}

void Parser:: query()
{
    
    
    predicate();
    match (Q_MARK);
    
    
    data.addQuery( temp );
	temp.clear_vector_param();
	
	//do i need to delete temp?
	
	//remember to clear vector to use later 
	//   this clears vector of parameters temp.clear_vector_param();
	// add predicate to program
    // program -> vector 
    
}

void Parser:: queryList()
{
    if ( get_next_token().get_TokenType() == ID)
    {
        query();
        queryList();
        
    }
    else
        return; 

}








//////////////////////////////////////////////////////////////////////////////////////////////////////////////

void Parser:: check_vector()
{
    
    for( Token tok : vector_of_tokens)
    {
        cout << type_of_token.at( tok.get_TokenType() ) << ", " << tok.get_TokenValue() << ", " << tok.get_TokenLineNum() << "." << endl; 
    }
    
}

void Parser:: delete_scheme()
{
    for ( Predicate predicate : data.get_schemes_vector()  )
	{
	    //cout << "S:DOOOOO" << endl;
	    for ( Parameter* p : predicate.get_param_vector() )
        {
            //cout << "S:THISSSSSSS" << endl;
            delete p;
        }
	}
}

void Parser:: delete_fact()
{
    for ( Predicate predicate : data.get_facts_vector() )
	{
	    //cout << "F:DOOOOO" << endl;
	    for ( Parameter* p : predicate.get_param_vector() )
        {
            //cout << "F:THISSSSSSS" << endl;
            delete p;
        }
	}
}

void Parser:: delete_rule()
{
    for ( Rule rul : data.get_rules_vector() )
	{
	    for ( Parameter* p : rul.get_headpredicate().get_param_vector() )
	    {
	        p->clear();
	        delete p; 
	    }
	    
	    for ( Predicate pred : rul.get_rule_predicates_vector() )
	    {
	        for ( Parameter* p : pred.get_param_vector() )
            {
                p->clear();
                delete p;
            }
	    }
	}
}

void Parser:: delete_queries()
{
    for ( Predicate predicate : data.get_queries_vector() )
	{
	   // cout << "Q:DOOOOO" << endl;
	    for ( Parameter* p : predicate.get_param_vector() )
        {
            //cout << "Q:THISSSSSSS" << endl;
            p->clear();
            delete p;
        }
	}
}

void Parser:: extra_deleting()
{
    
    for ( Parameter* p : temp.get_param_vector() )
    {
        // cout << "TEMP: " << p->param_toString() << "WHAT" << endl;
        p->clear();
        delete p;
    }
    
    // cout << "preds" << endl;
    for ( Predicate pred : temp3.get_rule_predicates_vector() )
    {
        // cout << "RUL PRED: " << pred.toString() << endl; 
        for ( Parameter* p : pred.get_param_vector() )
        {
            // cout << "TEMP3 P: " << p->param_toString() << endl; 
            p->clear();
            delete p;
        }                                                                        //  HasSameAddress(X,Y) :- snap(A),snap( ((x+y)Z) ).
    }
   
//   cout << "head" << endl;
     for ( Parameter* p : temp3.get_headpredicate().get_param_vector() )
    {
        // cout << "TEMP3 H: " << p->param_toString() << endl;
        p->clear();
        delete p; 
    }
    
//   cout << "ex start" << endl;
    for ( auto a : vec_of_ex )
    {
    //            cout << "Ex: " << a->param_toString() << endl;

        a->clear(); 
        delete a; 
    }
    // cout << "done" << endl;
    
}
/*
    something wrong with operator in expressions * or + 
    destructor, delete vector of pointer parameters 
    clear param/pred after done 
    remember to run valgrind 
*/

