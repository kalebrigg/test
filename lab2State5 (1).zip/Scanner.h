#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "Token.h"
#include "InputReader.h"

using namespace std;


class Scanner
{
    private:
        
        int number_of_tokens; 
        
    public:
        Scanner(); 
        
        vector<Token> tokens_created;
        
        vector<Token>  create_token( string file_name); 
        
        void string_function(  InputReader &i); 
        void comment_function( InputReader &i);
        void determine_if_ID_token( InputReader &i, char c);
        
        void get_token(); 
};


