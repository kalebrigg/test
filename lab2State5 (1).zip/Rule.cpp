#include "Rule.h"

using namespace std; 

void Rule:: setHeadPred ( Predicate pred)
{
    headpredicate = pred; 
}

void Rule:: addpredicate( Predicate pred)
{
     rule_predicates.push_back(pred);
}

void Rule:: clear_rule_predicates()
{
    rule_predicates.clear(); 
}

void Rule:: clear_headpred_param()
{
    headpredicate.clear_vector_param();
}


void Rule:: rule_toString()
{
    cout << headpredicate.toString();
    cout << ") :- ";
    bool first = true; 
    
    for ( Predicate pp : rule_predicates)
    {
        if (first)
        {
            first = false; 
        }
        else
        {
            cout << "),";
        }
            
        cout << pp.toString() ;
        
        
    }
    cout << ")."; 
    
    cout << endl; 
}

vector<Predicate> Rule:: get_rule_predicates_vector()
{
    return rule_predicates;
    
}

Predicate Rule:: get_headpredicate()
{
    return headpredicate; 
}