#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "DatalogProgram.h"
#include "Database.h"
#include "Predicate.h"
#include "Parameter.h"


using namespace std;


class Interpreter
{
    private:
       DatalogProgram mydata;
       
       Database datab;  
                
     
        
    public:
        Interpreter( DatalogProgram in );
        
        
        void make_relation();
        void fill_relation(); 
        
        void test_func(); 
        
        void evaluate_queries(); 
        
        void evaluate_predicate( Predicate p );
};



