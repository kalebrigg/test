#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <map>
#include "Relation.h"



using namespace std;


class Database: public map<string , Relation >
{
    private:
          
     
        
    public:
        
        
};


