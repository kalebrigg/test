#include "Relation.h"

using namespace std;

Relation:: Relation( string name, Scheme s)
{
    relation_name = name; 
    column_headers = s; 
    
}

void Relation:: add_tuple ( Tuple t)
{
    rows.insert( t ); 
    
}

Relation:: Relation ( string name, Scheme s , set<Tuple> new_set )
{
    relation_name = name; 
    column_headers = s;
    rows = new_set; 
    
}

Relation Relation:: select1 ( string s , int col_index )
{
    // cout << "START select function 1:" << endl; 
    // cout << "Looking for " << s << " in the " << col_index << " column." << endl; 
    set<Tuple> newset; 
    
    for( Tuple tuple : rows )
    {
        
        // cout << "Tuple: " << tuple.at(col_index ) << "compared to: " << s << endl; 
        
        if ( tuple.at( col_index )  == s )
		{
		  //  cout << "finds: " << tuple.at( col_index ) << endl; 
		    newset.insert( tuple );
		}	
		    

    }
    
    return Relation( relation_name , column_headers , newset ); 
    
}


Relation Relation:: select2 ( int col_index1, int col_index2 )
{
    set<Tuple> newset; 
    
    for ( auto tuple : rows )
    {
        
        if ( tuple.at( col_index1 ) == tuple.at( col_index2) )
		{
		    newset.insert(tuple);
		}
		
        
    }
    // return Relation(); 
    return Relation( relation_name , column_headers , newset  );
    
}

Relation Relation:: project ( vector<int> column_ints )
{
    Scheme new_scheme; 
     
    set<Tuple> new_rows; 
    
    for ( int i : column_ints )
    {
        string s = column_headers.at(i);
        new_scheme.push_back( s );
        
    }
    
    
    for ( auto tuple : rows )
    {
        Tuple tup;
        
        for ( int i : column_ints )
        {
            
            string t = tuple.at( i );
            tup.push_back( t ); 
        }
        
        new_rows.insert( tup );     
    }
    
    
    
    
    return Relation( relation_name, new_scheme, new_rows ); 
}
        
Relation Relation:: re_name ( Scheme s )
{

    return Relation( relation_name, s , rows); 
}




void Relation:: print_scheme_vec()
{
    int i = 0;
    cout << "Relation name: " << relation_name << endl; 
    for ( auto s : column_headers )
    {
        cout << "Column header (" << i <<  "): " <<  s << endl; 
        
        i++;
    }
}

void Relation:: print_rows()
{
    
    cout << "Relation name: " << relation_name << endl;
    
    for ( auto s : rows )
    {
        int i = 0;
        
        for ( auto a : s )
        {
            cout << "Tuple (" << i << "): " << s.at(i) << endl; 
        
            i++;
        }
        
    }
    
    
}

void Relation:: query_tostring( Predicate p)
{
    
    //cout << relation_name << "("; 
    
    cout << p.toString() << "? ";
    
    
    if (rows.size() > 0 )
    {
        cout << "Yes(" << rows.size() << ")" << endl;
        
        if (column_headers.size() == 0)
            return; 
        
    }
    else
    {
        cout << "No" << endl; 
    }
    
    
    int n = column_headers.size(); 
    
    for ( auto r : rows )
    {
        
        for ( int i = 0; i < n ; i++ )
        {
            if (i == 0)
            {
                cout << "  "; 
            }
            else
            {
                cout << ", ";
            }
            
            cout << column_headers[i] << "=" << r.at(i); 
        }
        cout << "\n"; 
    }
    
}