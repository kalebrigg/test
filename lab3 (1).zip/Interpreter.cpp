#include "Interpreter.h"

using namespace std;

Interpreter:: Interpreter( DatalogProgram in)
{
    mydata = in;
}

void Interpreter:: make_relation()
{
    
    
    
    for ( unsigned int i = 0; i < mydata.get_schemes_vector().size(); i++ )
    {
        Scheme s;   // should this be reset everytime?
        
        string n = mydata.get_schemes_vector()[i].get_headID(); 
        
        for ( unsigned int j = 0; j < mydata.get_schemes_vector()[i].get_param_vector().size(); j++)
        {
            
            string p = mydata.get_schemes_vector()[i].get_param_vector()[j]->get_param_value(); 
            s.push_back(p); 
        }
        
        
        
        datab.insert(pair<string, Relation>( n , Relation( n , s) ));
        //datab[n].print_scheme_vec(); 
        
    }
    
    //cout << "--------------------------------" << endl; 
    
        
}

void Interpreter:: fill_relation()
{
    
    
   // Tuple t;
    
    for( unsigned int i = 0; i < mydata.get_facts_vector().size(); i++)
    {
        Tuple t;// should this be reset everytime?? 
        
        string n = mydata.get_facts_vector()[i].get_headID(); 
        
        for ( unsigned int j = 0; j < mydata.get_facts_vector()[i].get_param_vector().size(); j++)
        {
            string p = mydata.get_facts_vector()[i].get_param_vector()[j]->get_param_value();
            t.push_back(p); 
            //cout << t.at(j) << endl; 
        }
        
        datab[n].add_tuple( t ); 
        //datab[n].print_rows(); 
    }
    
    
}

void Interpreter:: test_func() 
{ 
    vector<int> ints = { 1, 2 };
    Scheme s;
    s.push_back("X");
    s.push_back("Y");
    
    datab["SK"].print_scheme_vec();
    datab["SK"].print_rows();
    cout << "-------------" << endl; 
    
    Relation R1 = datab["SK"].select1( "\'1\'" , 0 );
    R1.print_scheme_vec(); 
    R1.print_rows(); 
    cout << "----------------------First Select" << endl; 
    
    Relation R2 = R1.select2( 1, 3 );
    R2.print_scheme_vec(); 
    R2.print_rows(); 
    cout << "----------------------Second Select" << endl; 
    
    Relation R3 = R2.project( ints );
    R3.print_scheme_vec(); 
    R3.print_rows(); 
    cout << "----------------------Project" << endl; 
    
    Relation R4 = R3.re_name( s );
    R4.print_scheme_vec(); 
    R4.print_rows(); 
    cout << "----------------------Rename" << endl; 
    
    
}

void Interpreter:: evaluate_queries()
{
    for (unsigned int i = 0; i < mydata.get_queries_vector().size(); i++ )
    {
        
        evaluate_predicate( mydata.get_queries_vector()[i] );
        
    }
    
    
}

void Interpreter:: evaluate_predicate( Predicate p )
{
    map<string,int> firstVar; 
    vector<int> ColsToKeep; 
    Scheme renameScheme; 
    
    Relation R1 = datab[ p.get_headID() ];
    
    for (unsigned int i = 0; i < p.get_param_vector().size(); i++ )
    {
        
        if ( p.get_param_vector()[i]->getPtype() == ParamType::param_STRING    )//FIX 
        {
            R1 = R1.select1( p.get_param_vector()[i]->get_param_value() , i );   // select 1
        }
        
        else
        {
            if (firstVar.find( p.get_param_vector()[i]->get_param_value()  ) == firstVar.end() )
            {
                
                firstVar.insert(pair<string, int>( p.get_param_vector()[i]->get_param_value() , i ));
                ColsToKeep.push_back( i );
                renameScheme.push_back( p.get_param_vector()[i]->get_param_value() );
                
            }
            else
            {
                auto it = firstVar.find( p.get_param_vector()[i]->get_param_value() );
                 R1 = R1.select2( i , it->second );
            }
            
        }
        
    }
    
    R1 = R1.project( ColsToKeep );
    R1 = R1.re_name( renameScheme);
    
    //R1.print_scheme_vec();
    //R1.print_rows(); 
  //  
    R1.query_tostring( p ); 
    
    
}