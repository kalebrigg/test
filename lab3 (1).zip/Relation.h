#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <set> 
#include <map>
#include "Scheme.h"
#include "Tuple.h"
#include "Predicate.h"


using namespace std;


class Relation
{
    private:
        string relation_name;
        Scheme column_headers;  // vector 
        set<Tuple> rows;        // set of Tuple, Tuple is vec of string
     
        
    public:
        Relation(){}
        Relation( string name, Scheme s );
        Relation( string name, Scheme s , set<Tuple> new_set );
        
        void add_tuple ( Tuple t );
        
        
        Relation select1 ( string s , int col_index );
        Relation select2 ( int col_index1, int col_index2 );
        
        Relation project ( vector<int> column_ints );
        
        Relation re_name ( Scheme s );
        
        void print_scheme_vec(); 
        void print_rows(); 
        void query_tostring( Predicate p ); 
};


